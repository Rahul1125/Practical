﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Practical_Jainam_ProductManagement.DBContext;
using Practical_Jainam_ProductManagement.Model;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Practical_Jainam_ProductManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : Controller
    {
        private readonly ProductDBContext _dbcontext;
        private readonly string _key;

        public AuthController( ProductDBContext context)
        {
            _dbcontext = context;
            _key = "eyJhbGciOiJIUzI1NiJ9.eyJSb2xlIjoiQWRtaW4iLCJJc3N1ZXIiOiJJc3N1ZXIiLCJVc2VybmFtZSI6IkphdmFJblVzZSIsImV4cCI6MTcyNjgwNzQ4NywiaWF0IjoxNzI2ODA3NDg3fQ.WNvNosGqNsw9IMgdXItV1Eojn4_vzX0QVJq97hAeyS4";

        }

        [HttpPost("login")]
        public async Task<ActionResult> Login(UserModel users)
        {
            var existingUser = await _dbcontext.Users.FirstOrDefaultAsync(u => u.Username == users.Username && u.Password == users.Password);

            if (existingUser != null)
                return Unauthorized();

            var tokenhandler = new JwtSecurityTokenHandler();
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new System.Security.Claims.ClaimsIdentity(new[]
                {new Claim(ClaimTypes.Name, existingUser.Username)
                }),
                Expires = DateTime.UtcNow.AddDays(7),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(Encoding.ASCII.GetBytes(_key)), SecurityAlgorithms.HmacSha256Signature)

            };

            var token = tokenhandler.CreateToken(tokenDescriptor);
            return Ok(new { Token = tokenhandler.WriteToken(token) });  
        }
    }
}
