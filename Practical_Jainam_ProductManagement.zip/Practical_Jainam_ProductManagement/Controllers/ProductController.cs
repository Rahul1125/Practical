﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Practical_Jainam_ProductManagement.DBContext;
using Practical_Jainam_ProductManagement.Model;
using System.Threading.Tasks;

namespace Practical_Jainam_ProductManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        #region database 
        private readonly ProductDBContext _dbcontext;

        public ProductController(ProductDBContext dbcontext)
        {
            _dbcontext = dbcontext;
        }
        #endregion

        #region Fetch Product Data
        //[Authorize]
        
        [HttpGet]
        public async Task<List<Product>> GetProducts()
        {
            var productResult = await _dbcontext.productdbset.ToListAsync();

            return productResult;
        }


        [HttpGet("{id}")]
        public async Task<ActionResult<Product>> GetProducts(int id)
        {
            var product = await _dbcontext.productdbset.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            return product;

        }
        #endregion

        #region Create Product
        [HttpPost]
        public async Task<ActionResult<Product>> CreateProduct(Product product)
        {        
            if (string.IsNullOrEmpty(product.ProductName) || product.CompletionDate <= DateTime.Now)
            {
                return BadRequest("Product name cannot be empty and completion date must be in the future.");
            }

            _dbcontext.productdbset.Add(product);
            await _dbcontext.SaveChangesAsync();           
            return CreatedAtAction(nameof(GetProducts), new { id = product.ProductID}, product);
        }
        #endregion

        #region Update Product 
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProduct(int id, Product product)
        {
            if (id != product.ProductID)
            {
                return BadRequest();
            }
            if (string.IsNullOrWhiteSpace(product.ProductName) || product.CompletionDate <= DateTime.Now)
            {

                return BadRequest("Product name cannot be empty and completion date must be in the future.");
            }

            _dbcontext.Entry(product).State = EntityState.Modified;

            try
            {
                await _dbcontext.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ProductExists(id))
                {
                    return NotFound();
                }
                throw;
            }

           return CreatedAtAction(nameof(GetProducts), new { id = product.ProductID }, product);

        }


        private bool ProductExists(int id)
        {
            return _dbcontext.productdbset.Any(e => e.ProductID == id);
        }

        #endregion

        #region Delete Product 
        [HttpDelete("{id}")]
        public async Task<string> DeleteProduct(int id)
        {
            var result = await _dbcontext.productdbset.FindAsync(id);
            if (result == null)
            {
                return "Record Not Found";
            }

            _dbcontext.productdbset.Remove(result);
            await _dbcontext.SaveChangesAsync();

            return "Record Deleted succefully!" ;
        }
        #endregion
    }
}
