﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Practical_Jainam_ProductManagement.DBContext;
using Practical_Jainam_ProductManagement.Model;

namespace Practical_Jainam_ProductManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductPaginationSortingFilterController : Controller
    {

        #region database 
        private readonly ProductDBContext _dbcontext;

        public ProductPaginationSortingFilterController(ProductDBContext dbcontext)
        {
            _dbcontext = dbcontext;
        }

        [HttpGet]
        public async Task<ActionResult<Practical_Jainam_ProductManagement.Model.PagedResponse<Product>>> GetProducts(
            string sort = "name",
            string order = "asc",
            string filter = null,
            int page = 1,
            int pageSize = 10)
        {
            // Fetch all products from the service
            var products = await _dbcontext.GetAllProductsAsync();

            // Apply filtering if specified
            if (!string.IsNullOrEmpty(filter))
            {
                // Example filtering by a property, e.g., "category"
                products = products.Where(p => p.Category == filter).ToList();
            }

            // Apply sorting
            products = order.ToLower() == "desc"
                ? products.OrderByDescending(p => EF.Property<object>(p, sort)).ToList()
                : products.OrderBy(p => EF.Property<object>(p, sort)).ToList();

            // Apply pagination
            var totalItems = products.Count();
            var items = products.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            var response = new PagedResponse<Product>
            {
                Items = items,
                TotalItems = totalItems,
                CurrentPage = page,
                PageSize = pageSize,
                TotalPages = (int)Math.Ceiling(totalItems / (double)pageSize)
            };

            return Ok(response);
        }

        public Task<List<Product>> GetAllProductsAsync()
        {
            return NoContent(); // Task.FromResult();
        }
    }
}
