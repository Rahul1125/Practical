﻿using Microsoft.EntityFrameworkCore;
using Practical_Jainam_ProductManagement.Model;

namespace Practical_Jainam_ProductManagement.DBContext
{
    public class ProductDBContext : DbContext
    {
        public ProductDBContext(DbContextOptions<ProductDBContext> options) : base(options) { }

        public DbSet<Product> productdbset { get; set; }

        public DbSet<UserModel> Users { get; set; }
    }
}
