﻿using Practical_Jainam_ProductManagement.Middlewares;
using System.ComponentModel.DataAnnotations;

namespace Practical_Jainam_ProductManagement.Model
{
    public class Product
    {
        [Required]
        public int ProductID { get; set; }

        [Required(ErrorMessage = "Name is required.")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Name must be between 2 and 50 characters.")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Name can only contain letters and spaces.")]
        public string ProductName { get; set; }

        [Required(ErrorMessage = "Completion date is required.")]
        [DataType(DataType.Date)]
        [CustomDateValidation(ErrorMessage = "Completion date must be in the future.")]
        public DateTime CompletionDate { get; set; }
    }
}
